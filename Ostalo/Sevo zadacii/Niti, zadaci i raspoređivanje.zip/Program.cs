﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ScosPresentation
{
    class Program
    {
        static void Main(string[] args)
        {
            //SimpleScheduler.Demo();
            //NaiveTaskScheduler.Demo();
            //SimpleWaveWriter.Demo();
            RaceConditioner.Demo();
        }
    }
}